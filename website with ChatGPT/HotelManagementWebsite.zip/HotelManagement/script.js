$(document).ready(function(){
$("#bookingForm").submit(function(e){e.preventDefault();var a=$("#checkin").val(),b=$("#checkout").val();if(!a||!b){alert("Please select check-in and check-out dates.");return}if(b<=a){alert("Check-out date must be after check-in date.");return}$("#bookingMessage").text("Rooms are available for your selected dates!").fadeIn()});
$(".book-room").click(function(){$("#selectedRoom").val($(this).data("room"));$("#bookingModal").modal("show")});
$("#modalBookingForm").submit(function(e){e.preventDefault();alert("Booking request submitted successfully!");$("#bookingModal").modal("hide");this.reset()});
$("#contactForm").submit(function(e){e.preventDefault();$("#contactMessage").hide().fadeIn();this.reset()});
$(".navbar-nav .nav-link").click(function(){$(".navbar-collapse").collapse("hide")});
$(".gallery-img").hover(function(){$(this).css("opacity",".8")},function(){$(this).css("opacity","1")});
});